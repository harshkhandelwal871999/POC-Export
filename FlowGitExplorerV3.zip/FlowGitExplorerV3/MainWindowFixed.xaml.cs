﻿using System.Diagnostics;
using System.Text;
using System.Windows;
using System.Windows.Controls;
namespace FlowGitExplorerV3;
public partial class MainWindow : Window
{
    private sealed record Node(string Path, bool IsFlow);
    private Node? selected;
    public MainWindow() { InitializeComponent(); }
    private string Repo => Path.GetFullPath(RepoBox.Text.Trim());
    private string Auth => Convert.ToBase64String(Encoding.UTF8.GetBytes($"x-access-token:{PatBox.Password}"));
    private async void LoadClick(object sender, RoutedEventArgs e) { try { await EnsureRepo(); LoadedText.Text = Repo; await Refresh(); } catch (Exception x) { Write("ERROR: " + (string.IsNullOrWhiteSpace(x.Message) ? x.GetType().Name : x.Message)); } }
    private async Task EnsureRepo()
    {
        if (string.IsNullOrWhiteSpace(RemoteBox.Text) || string.IsNullOrWhiteSpace(PatBox.Password) || string.IsNullOrWhiteSpace(RepoBox.Text)) throw new InvalidOperationException("Set GitHub URL, PAT, local repo folder.");
        if (Directory.Exists(Path.Combine(Repo, ".git"))) { var set = await Git("remote set-url origin " + Q(RemoteBox.Text.Trim()), Repo); if (!set.ok) throw new InvalidOperationException(set.text); return; }
        if (Directory.Exists(Repo) && Directory.EnumerateFileSystemEntries(Repo).Any()) throw new InvalidOperationException("Local repo folder exists and is not empty. Choose empty folder or existing Git folder.");
        Directory.CreateDirectory(Path.GetDirectoryName(Repo)!);
        var r = await Git("clone --no-checkout " + Q(RemoteBox.Text.Trim()) + " " + Q(Repo), Path.GetDirectoryName(Repo)!); if (!r.ok) throw new InvalidOperationException(r.text);
        Write("Repository initialized inside: " + Repo);
    }
    private async Task<string?> ResolveRemoteBranch()
    {
        var refs = await Git("ls-remote --heads origin", Repo);
        if (!refs.ok) throw new InvalidOperationException(refs.text);
        var branches = refs.text.Split(["\r\n", "\n"], StringSplitOptions.RemoveEmptyEntries).Select(x => x.Split('\t').Last().Replace("refs/heads/", "")).Where(x => !string.IsNullOrWhiteSpace(x)).ToList();
        return branches.FirstOrDefault(x => x.Equals("main", StringComparison.OrdinalIgnoreCase)) ?? branches.FirstOrDefault(x => x.Equals("master", StringComparison.OrdinalIgnoreCase)) ?? branches.FirstOrDefault();
    }
    private async Task Refresh()
    {
        var f = await Git("fetch origin", Repo); if (!f.ok) throw new InvalidOperationException(f.text);
        var branch = await ResolveRemoteBranch();
        Tree.Items.Clear();
        if (branch is null) { Tree.Items.Add(new TreeViewItem { Header = "repository (empty)" }); Write("Remote is empty. Use Check in one flow to create first commit."); return; }
        var r = await Git("ls-tree -r --name-only " + Q("origin/" + branch), Repo); if (!r.ok) throw new InvalidOperationException(r.text);
        var root = new TreeViewItem { Header = "repository (" + branch + ")" }; var groups = r.text.Split(["\r\n", "\n"], StringSplitOptions.RemoveEmptyEntries).Select(p => p.Replace('/', '\\').Split('\\')).Where(p => p.Length >= 2).GroupBy(p => p[0]).OrderBy(g => g.Key);
        foreach (var team in groups) { var t = new TreeViewItem { Header = team.Key }; foreach (var flow in team.Select(x => x[1]).Distinct().OrderBy(x => x)) t.Items.Add(new TreeViewItem { Header = flow, Tag = new Node(team.Key + "/" + flow, true) }); root.Items.Add(t); } root.IsExpanded = true; Tree.Items.Add(root); Write("Repository refreshed. Branch: " + branch);
    }
    private void SelectClick(object s, RoutedPropertyChangedEventArgs<object> e) { selected = (e.NewValue as TreeViewItem)?.Tag as Node; SelectedText.Text = selected?.Path ?? "Nothing selected"; }
    private void BrowseClick(object sender, RoutedEventArgs e) { var picker = new Microsoft.Win32.OpenFolderDialog { Title = "Select exported Leapwork flow folder" }; if (picker.ShowDialog() == true) SourceBox.Text = picker.FolderName; }
    private async void CheckInClick(object s, RoutedEventArgs e)
    {
        try
        {
            await EnsureRepo();
            var source = SourceBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(source)) throw new InvalidOperationException("Choose flow folder with Browse.");
            if (string.IsNullOrWhiteSpace(TeamBox.Text)) throw new InvalidOperationException("Team name required in Settings.");
            var flow = Path.GetFileName(Path.TrimEndingDirectorySeparator(source));
            var dest = Path.Combine(Repo, TeamBox.Text.Trim(), flow);
            if (!Directory.Exists(source))
            {
                if (!Directory.Exists(dest)) throw new DirectoryNotFoundException("Flow folder not found: " + source);
                source = dest; SourceBox.Text = dest; Write("Entered path not found. Using existing local flow: " + dest);
            }
            var branch = await ResolveRemoteBranch();
            if (branch is null) { branch = "main"; var create = await Git("checkout --orphan " + Q(branch), Repo); if (!create.ok) throw new InvalidOperationException(create.text); }
            var sameFolder = string.Equals(Path.TrimEndingDirectorySeparator(Path.GetFullPath(source)), Path.TrimEndingDirectorySeparator(Path.GetFullPath(dest)), StringComparison.OrdinalIgnoreCase);
            if (!sameFolder) { if (Directory.Exists(dest)) Directory.Delete(dest, true); Copy(source, dest); }
            var placeholders = AddGitKeepFiles(dest);
            if (placeholders > 0) Write("Added .gitkeep to " + placeholders + " empty folder(s).");
            var path = Q((TeamBox.Text.Trim() + "/" + flow).Replace('\\', '/')); var add = await Git("add -- " + path, Repo); if (!add.ok) throw new InvalidOperationException(add.text);
            await EnsureCommitIdentity();
            var c = await Git("commit -m " + Q(MessageBox.Text.Trim()) + " -- " + path, Repo); if (!c.ok) throw new InvalidOperationException(c.text);
            var p = await Git("push origin HEAD:" + Q(branch), Repo); if (!p.ok) throw new InvalidOperationException(p.text); Write("Checked in exactly one flow: " + TeamBox.Text.Trim() + "/" + flow); await Refresh();
        }
        catch (Exception x) { Write("ERROR: " + (string.IsNullOrWhiteSpace(x.Message) ? x.GetType().Name : x.Message)); }
    }
    private async void FetchClick(object s, RoutedEventArgs e) { try { if (selected is null || !selected.IsFlow) throw new InvalidOperationException("Select one flow."); var f = await Git("fetch origin", Repo); if (!f.ok) throw new InvalidOperationException(f.text); var branch = await ResolveRemoteBranch(); if (branch is null) throw new InvalidOperationException("Remote is empty."); var r = await Git("restore --source " + Q("origin/" + branch) + " --worktree --staged -- " + Q(selected.Path), Repo); if (!r.ok) throw new InvalidOperationException(r.text); Write("Fetched only: " + selected.Path); } catch (Exception x) { Write("ERROR: " + (string.IsNullOrWhiteSpace(x.Message) ? x.GetType().Name : x.Message)); } }
    private async Task EnsureCommitIdentity()
    {
        var name = await Git("config --get user.name", Repo); if (string.IsNullOrWhiteSpace(name.text)) await Git("config user.name " + Q(Environment.UserName), Repo);
        var email = await Git("config --get user.email", Repo); if (string.IsNullOrWhiteSpace(email.text)) await Git("config user.email " + Q(Environment.UserName + "@leapwork.local"), Repo);
    }
    private async Task<(bool ok, string text)> Git(string args, string cwd) { var p = new ProcessStartInfo("git", "-c credential.helper= " + args) { WorkingDirectory = cwd, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true }; p.Environment["GIT_TERMINAL_PROMPT"] = "0"; p.Environment["GCM_INTERACTIVE"] = "Never"; if (!string.IsNullOrWhiteSpace(PatBox.Password)) { p.Environment["GIT_CONFIG_COUNT"] = "1"; p.Environment["GIT_CONFIG_KEY_0"] = "http.extraheader"; p.Environment["GIT_CONFIG_VALUE_0"] = "AUTHORIZATION: basic " + Auth; } using var x = Process.Start(p)!; var o = await x.StandardOutput.ReadToEndAsync(); var er = await x.StandardError.ReadToEndAsync(); await x.WaitForExitAsync(); return (x.ExitCode == 0, (o + er).Trim()); }
    private static string Q(string x) => "\"" + x.Replace("\"", "\\\"") + "\"";
    private static int AddGitKeepFiles(string root)
    {
        var count = 0;
        foreach (var dir in Directory.EnumerateDirectories(root, "*", SearchOption.AllDirectories))
            if (!Directory.EnumerateFileSystemEntries(dir).Any()) { File.WriteAllText(Path.Combine(dir, ".gitkeep"), "This file preserves an otherwise empty folder in Git." + Environment.NewLine); count++; }
        return count;
    }
    private static void Copy(string s, string d) { Directory.CreateDirectory(d); foreach (var f in Directory.EnumerateFiles(s)) File.Copy(f, Path.Combine(d, Path.GetFileName(f)), true); foreach (var x in Directory.EnumerateDirectories(s)) Copy(x, Path.Combine(d, Path.GetFileName(x))); }
    private void Write(string x) => Log.AppendText($"[{DateTime.Now:HH:mm:ss}] {x}{Environment.NewLine}");
}






