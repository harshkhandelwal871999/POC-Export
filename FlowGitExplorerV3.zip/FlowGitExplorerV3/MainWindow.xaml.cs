using System.Diagnostics;
using System.Text;
using System.Windows;
using System.Windows.Controls;
namespace FlowGitExplorerV3;
public partial class MainWindow : Window
{
    private sealed record Node(string Path, bool IsFlow);
    private Node? selected;
    public MainWindow() { InitializeComponent(); }
    private string Repo => Path.GetFullPath(RepoBox.Text.Trim());
    private string Auth => Convert.ToBase64String(Encoding.UTF8.GetBytes($"x-access-token:{PatBox.Password}"));
    private async void LoadClick(object sender, RoutedEventArgs e) { try { await EnsureRepo(); LoadedText.Text = Repo; await Refresh(); } catch (Exception x) { Write("ERROR: " + x.Message); } }
    private async Task EnsureRepo()
    {
        if (string.IsNullOrWhiteSpace(RemoteBox.Text) || string.IsNullOrWhiteSpace(PatBox.Password) || string.IsNullOrWhiteSpace(RepoBox.Text)) throw new InvalidOperationException("Set GitHub URL, PAT, local repo folder.");
        if (Directory.Exists(Path.Combine(Repo, ".git"))) { await Git("remote set-url origin " + Q(RemoteBox.Text.Trim()), Repo); return; }
        if (Directory.Exists(Repo) && Directory.EnumerateFileSystemEntries(Repo).Any()) throw new InvalidOperationException("Local repo folder exists and is not empty. Choose empty folder or existing Git folder.");
        Directory.CreateDirectory(Path.GetDirectoryName(Repo)!);
        var r = await Git("clone --no-checkout " + Q(RemoteBox.Text.Trim()) + " " + Q(Repo), Path.GetDirectoryName(Repo)!); if (!r.ok) throw new InvalidOperationException(r.text);
        Write("Repository initialized inside: " + Repo);
    }
    private async Task Refresh()
    {
        var f = await Git("fetch origin", Repo); if (!f.ok) throw new InvalidOperationException(f.text);
        var r = await Git("ls-tree -r --name-only origin/HEAD", Repo); if (!r.ok) throw new InvalidOperationException("Remote has no commits, or origin/HEAD is unavailable: " + r.text);
        Tree.Items.Clear(); var root = new TreeViewItem { Header = "repository" }; var groups = r.text.Split(["\r\n", "\n"], StringSplitOptions.RemoveEmptyEntries).Select(p => p.Replace('/', '\\').Split('\\')).Where(p => p.Length >= 2).GroupBy(p => p[0]).OrderBy(g => g.Key);
        foreach (var team in groups) { var t = new TreeViewItem { Header = team.Key }; foreach (var flow in team.Select(x => x[1]).Distinct().OrderBy(x => x)) t.Items.Add(new TreeViewItem { Header = flow, Tag = new Node(team.Key + "/" + flow, true) }); root.Items.Add(t); } root.IsExpanded = true; Tree.Items.Add(root); Write("Repository refreshed. Remote default branch detected via origin/HEAD.");
    }
    private void SelectClick(object s, RoutedPropertyChangedEventArgs<object> e) { selected = (e.NewValue as TreeViewItem)?.Tag as Node; SelectedText.Text = selected?.Path ?? "Nothing selected"; }
    private async void CheckInClick(object s, RoutedEventArgs e)
    { try { await EnsureRepo(); var source = SourceBox.Text.Trim(); if (!Directory.Exists(source)) throw new DirectoryNotFoundException(source); if (string.IsNullOrWhiteSpace(TeamBox.Text)) throw new InvalidOperationException("Team name required."); var flow = Path.GetFileName(Path.TrimEndingDirectorySeparator(source)); var dest = Path.Combine(Repo, TeamBox.Text.Trim(), flow); if (Directory.Exists(dest)) Directory.Delete(dest, true); Copy(source, dest); var path = Q((TeamBox.Text.Trim() + "/" + flow).Replace('\\', '/')); var add = await Git("add -- " + path, Repo); if (!add.ok) throw new InvalidOperationException(add.text); var c = await Git("commit -m " + Q(MessageBox.Text.Trim()) + " -- " + path, Repo); if (!c.ok) throw new InvalidOperationException(c.text); var branch = await Git("branch --show-current", Repo); if (!branch.ok || string.IsNullOrWhiteSpace(branch.text)) throw new InvalidOperationException("Could not determine local branch."); var p = await Git("push origin HEAD:" + Q(branch.text.Trim()), Repo); if (!p.ok) throw new InvalidOperationException(p.text); Write("Checked in exactly one flow: " + TeamBox.Text.Trim() + "/" + flow); await Refresh(); } catch (Exception x) { Write("ERROR: " + x.Message); } }
    private async void FetchClick(object s, RoutedEventArgs e) { try { if (selected is null || !selected.IsFlow) throw new InvalidOperationException("Select one flow."); var f = await Git("fetch origin", Repo); if (!f.ok) throw new InvalidOperationException(f.text); var r = await Git("restore --source origin/HEAD --worktree --staged -- " + Q(selected.Path), Repo); if (!r.ok) throw new InvalidOperationException(r.text); Write("Fetched only: " + selected.Path); } catch (Exception x) { Write("ERROR: " + x.Message); } }
    private async Task<(bool ok, string text)> Git(string args, string cwd) { var p = new ProcessStartInfo("git", args) { WorkingDirectory = cwd, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true }; if (!string.IsNullOrWhiteSpace(PatBox.Password)) { p.Environment["GIT_CONFIG_COUNT"] = "1"; p.Environment["GIT_CONFIG_KEY_0"] = "http.extraheader"; p.Environment["GIT_CONFIG_VALUE_0"] = "AUTHORIZATION: basic " + Auth; } using var x = Process.Start(p)!; var o = await x.StandardOutput.ReadToEndAsync(); var er = await x.StandardError.ReadToEndAsync(); await x.WaitForExitAsync(); return (x.ExitCode == 0, (o + er).Trim()); }
    private static string Q(string x) => "\"" + x.Replace("\"", "\\\"") + "\"";
    private static void Copy(string s, string d) { Directory.CreateDirectory(d); foreach (var f in Directory.EnumerateFiles(s)) File.Copy(f, Path.Combine(d, Path.GetFileName(f)), true); foreach (var x in Directory.EnumerateDirectories(s)) Copy(x, Path.Combine(d, Path.GetFileName(x))); }
    private void Write(string x) => Log.AppendText($"[{DateTime.Now:HH:mm:ss}] {x}{Environment.NewLine}");
}
