using System.Windows; namespace FlowGitExplorerV3; public partial class App : Application { }
